#!/bin/sh
echo "$@"
node -v